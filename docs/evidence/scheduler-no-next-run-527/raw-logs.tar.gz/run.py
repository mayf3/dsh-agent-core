import subprocess, sys, json, pathlib, re, datetime, time
name,cwd,*cmd=sys.argv[1:]
root=pathlib.Path('/tmp/dsh-527-fix-evidence')
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.tap')).open('w') as log:
 result=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
raw=(root/(name+'.tap')).read_text()
counts={key:int(value) for key,value in re.findall(r'^(?:#|ℹ) (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\s*$',raw,re.M)}
raw_names=re.findall(r'^\s*not ok \d+ - (.+)$',raw,re.M) + re.findall(r'^\s*✖ (.+?) \([\d.]+ms\)$',raw,re.M)
failed=sorted(set(n.replace('/private/tmp/dsh-527-probe-baseline/','<repo>/').replace('/tmp/dsh-527-probe-baseline/','<repo>/').replace('/private/tmp/dsh-527-probe/','<repo>/').replace('/tmp/dsh-527-probe/','<repo>/') for n in raw_names))
record=dict(name=name,command=cmd,cwd=cwd,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),started=start,ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),rc=result.returncode,counts=counts,failed_names=failed,raw_failed_names=raw_names)
(root/(name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False))
