# 身份收敛与旧执行逻辑退役实施方案

> 交付给既有 ZCode「每30分钟推进backlog功能上线部署队列」监管任务及现有 Sol 6.1 ultra。沿现有执行方式在隔离分支逐项推进，不另起并行实现 writer。实施时遵守仓库开发协议；可使用 executing-plans，受影响范围完成后复用既有独立审查链。

**Goal：** 新产生的任务责任只使用经过权威验证的 canonical 身份；当前责任判定与展示同源；旧身份仅作为有限迁移与审计来源，按明确条件退役旧认证和兼容执行入口。

**Architecture：** Auth 负责认证与 canonical 身份事实，Workflow 负责当前责任与事务授权，Broker/dispatcher 消费服务端结果，不自行解释两个 UUID 是否同一人。保留不可变历史及迁移来源，收敛所有新写入和当前业务表面；不新增一套身份映射服务，不用会话重置或全舰队广播代替修复。

**Tech Stack：** 现有 svc-workflow Rust/PostgreSQL、dsh-agent-core JavaScript 工具与 dispatcher、现有 Auth directory/admission、原测试和治理流水线。

**Spec：** 复用 `svc-workflow/docs/specs/SVC_WORKFLOW_CANONICAL_IDENTITY_RECONCILIATION_V2.md`、现有 P9 principal successor projection 合同与 `dsh-agent-core/docs/specs/AGENT_CORE_WORKFLOW_ASSIGNEE_TRANSITION_CAPABILITY_V1.md`。本文件是实施/交接计划，不自行把拟议语义变成 accepted Spec。仅真实不足的语义走有限 amendment；覆盖范围已有 accepted Spec 时直接实现，不另加一般 Owner 门。

状态：**PLAN_READY / SOURCE_WORK_AUTHORIZED_BY_USER / NO_PRODUCTION_CHANGE**。核对时间 2026-10-24；远端 issue/commit 与有限本地源码核对，不含生产 DB、凭据、会话重置或真实业务 transition。

## 1. 全局边界与复用规则

- 唯一生产 writer 及现有部署线不变；本任务不能安装、重启、改权限/凭据/生产配置、迁移生产 DB、清会话、关闭守卫或代 CTO 推进任务。已有部署在途事项按其原授权运行，本计划不插入并行维护。
- 根治对象是重复身份判断、新 legacy 责任产生源、旧认证/执行入口和没有退出条件的兼容分支。历史 UUID、原 node_visits、原事件、lineage 仍保留。
- 不用显示名、角色名、`agt_` 前缀、UUID 形状或客户端 alias 推导身份；只用原权威映射及其明确范围。原 assignee 继任不自动继承 creator、Domain Owner、admin 或 auditor 权限。
- `executable_for_actor` 继续是 **ADVISORY_ONLY**。最终权限、当前状态、业务字段、CAS、assistance 等检查留在执行事务。Broker 不增加权限缓存或预授权判定。
- 不加 `current_assignee_is_actor` / `you_are_the_assignee`；不把清空 MEMORY/AGENTS/main session、全舰队通告平台作为默认方案。
- `UNKNOWN` 的已发写入先恢复同一请求结果；不能因刷新身份、换会话、换 requestId 自动重发。过往明确拒绝的观察也不能变成永久规则，新的合法工作恢复使用当前服务端状态。
- 所有源改动在 `codex/identity-convergence-*` 隔离分支/工作树；既有作者先确认文件归属。禁止覆盖共享工作区未提交修改。每项复用已修 commit/测试/审查，只新增被本差量影响的验证。

## 2. 已修内容：先接入，不重做

| 对象 | 本轮核实 | 此计划动作 |
| --- | --- | --- |
| svc-workflow #82 | 本地 HEAD `10310a4140cfdec0ce152ad89adc5b98bd7ddf01` 已有共享 effective-assignee helper，接 detail/history visibility、advisory、transition、revise+transition 四处；`tests/32_canonical_assignee_continuity.rs` 已存在。生产通过是 issue/原作者报告，本轮未复测。 | 原样复用修复和测试。先处理下述主线分叉，新增问题不能重写这四处。 |
| #82 主线集成 | 远端 main `bfc28c15320acab8cf7d7a36128cd5c9db9a1b1a`；`10310a4...main` 为 diverged，ahead14/behind3，merge-base `18fb2f8bc80983a36b15e65bf51d8f5c4b64fb78`。限定 `feat/global-workflow-auditor` head 查询未找到 PR。 | 不能从旧 main 发版抹掉已部署修复；也不能把分叉整支的其他权限变化盲并。接手时核最终选定 base，保留现有修复再增量接入。 |
| dsh #550 | deepseek-harness PR4 已合并 `c211b445593fa5639075dc690801a3a3005ca0dd`；原 reviewed head `f40ab9c5b0bbdba31fd52aab415451698dc1a32d`。已注册具体事件，非 wildcard-ignore。 | 只沿原 release/bundle 跟踪部署与业务验收，不再修一遍，也不借身份项目清真实 session。 |
| dsh #554 A | PR555 已合并 `3c651a6ea4cab45d9c8520f6ecc92f9478312eab`，原 head `0ffb21754500551923be73ba88b6382474fb6b0b`；aux partial 与生产 bundle 生命周期分开。 | 复用监听器隔离。B 的 8788 路由仍沿 #525 交付，不另造 admission 服务。后续有界重试差量按原线处理。 |
| dsh #552 / PR553 | PR553 OPEN，head `de10045e7bdcd5c728c46d0c6ec0e25a8c7c6de6`。最新契约为 **0600 + reader UID ownership**，早期 0640/group 方案不可重新采用。 | 复用现有源/评审/Spec 流程；身份方案不复制 secret、改 UID 或批量重赋权。 |
| svc-workflow #81 | canonical provisioning allowlist、canonical HR admin grant、admission 依赖有分开的已报缺口。 | allowlist 源配置按其角色修；admin grant 是 Auth 权限决策，不能由 successor 自动复制。也不能把 HR admin 问题当全部 assignee transition 的前置门。 |
| #1276 | 部署流程优化与耗时事件模型已经交接。 | 复用其计时与证据格式，不新建平行观测体系或重复部署改革。 |

来源：[#82](https://github.com/mayf3/svc-workflow/issues/82)、[#81](https://github.com/mayf3/svc-workflow/issues/81)、[#80](https://github.com/mayf3/svc-workflow/issues/80)、[#550](https://github.com/mayf3/dsh-agent-core/issues/550)、[#552](https://github.com/mayf3/dsh-agent-core/issues/552)、[#553](https://github.com/mayf3/dsh-agent-core/pull/553)、[#554](https://github.com/mayf3/dsh-agent-core/issues/554)、[#555](https://github.com/mayf3/dsh-agent-core/pull/555)、[#1257](https://github.com/mayf3/agent-control/issues/1257)、[#1276](https://github.com/mayf3/agent-control/issues/1276)。

**并行工作交接提醒：** 本轮 ZCode UI 可见「飞书群与 Agent 映射冲突排查」正在改 creator-draft，并报告 domain-owner deny 测试失败待查；这是对话可见状态，不是本轮对它的 diff/测试结论。监管应先取得该作者已有分支/差量/回执，不派第二作者重做。尤其不得把 `created_by` 也顺手改成 assignee successor 判定；下文 T2 明确保留 creator 权限边界。本任务交付只到隔离源/审查，不以该对话提到的“完整发布”扩展用户本次范围。

## 3. 真正需要修的差量与文件地图

以下行号绑定本轮核到的本地 `svc-workflow` HEAD 10310a4，执行时只对变化的目标核基线，不重新遍历旧证据。

| 差量 | 现有入口 | 修复方向 |
| --- | --- | --- |
| 新事实仍可保存旧责任 | `src/store/postgres/admission_gate.rs:165,179` 验 canonical 后只返回 `Result<()>`；`workflow_instance_repository/create_transaction.rs:384,464`、`transition_transaction.rs:558,623` 仍写原 target。 | 把“通过 admission 的最终责任身份”带到持久化边界；输入来源与当前责任分离。先修 Spec，再改与该旧行为绑定的 T62。 |
| 已有测试有意保留 P | `tests/31_admission_wiring.rs:949–1099` 的 T62 验 Q、写 P。 | 这是已知旧语义，不是假装一个漏测 bug。有限 amendment 明确新写入 Q/原历史 P 保留后，替换其预期并补反例。 |
| creator-draft advisory 不一致 | `workflow_instance_repository/query_worklists.rs:236` current-assignee 裸比较；`:224` creator exact 过滤，`combined_transaction.rs:205` creator exact 检查。 | 只统一 assignee 子谓词。非 creator 的 successor 不获得 revise/creator-draft 权力。 |
| assistance/assigned-list 语义未统一 | `assistance_transaction/write.rs:64` 裸 assignee；`query_worklists.rs:112` stored actor OR resolved actor。 | 先按角色矩阵决定现有服务端共同 predicate 的适用，不做全局文本替换。对旧 actor 仍 active 的分支做权限反例。 |
| canonical enrichment 不完整 | `query_visibility.rs:241,269` 为 LEFT JOIN enrichment；`src/application/workflow_instance/query_types.rs:158` 允许 native canonical 和无 lineage 两种情况都 null。 | 当前业务投影必须区分可解析与未解析。不能把 null 一律拒绝，也不能在 Broker 根据前缀填值。 |
| 消费端可能二次解释身份 | DSH `packages/broker/src/capabilities/workflow.js:83,107` 现为透传。 | 保持透传与服务端裁决；调整通用工具/dispatcher 消费合同和有实证的旧否决规则，不在 Broker 造映射。 |

现有生成/admission 入口优先复用：

- definition publish/defaults/enums/fixed roles：`src/application/definition/lifecycle/publish.rs:110,128`，`tests/32_definition_publish_admission.rs`。
- create/revise/combined：`create_transaction.rs:371–385`、`revise_transaction.rs:404,440`、`combined_transaction.rs:353–375`。
- transition/RETURN：`transition_transaction.rs:546–561`；admin override：`admin_recovery_repository/override_transaction.rs:370,381`；repair：`workflow_instance_repository/repair_transaction.rs:482,491`。
- 现有 admission 可 dormant/no-op（`admission_gate.rs:23`）；测试必须覆盖 enabled 和 disabled 合同，不能凭函数存在声称生产已启用。
- 复用 `tests/17_workflow_runtime/{combined,transition,admin_recovery,query}`、`tests/31_admission_wiring.rs`、`tests/32_canonical_assignee_continuity.rs`、`tests/34_identity_repair_operator.rs`。不重建另一套数据库测试架构。

本轮 DSH 本地 HEAD `e9699aee6beb1d6811e3a77f0cb4c08088241348` 且 broker 有其他本地改动，地图只是本地观察，不代表 main/installed。接入必须用隔离工作树与原作者文件交接。

## 4. 收敛后的目标合同

### 4.1 权威、历史与当前责任

| 层 | 唯一职责 | 明确不做 |
| --- | --- | --- |
| Auth / 原 canonical directory | 当前认证 principal、agent canonical pair、enabled/revoked 状态 | 不根据 Workflow 显示名赋身份，不自动复制旧 grants |
| Workflow 当前责任解析 | 在同一事务/快照中把合法原责任解析为当前 effective assignee；缺失/歧义失败闭合 | 不扩成所有角色通用的 alias-login，不做任意多跳猜测 |
| 当前业务 API | detail/my_tasks/dispatcher 展示同一 effective 责任；advisory 有明确时效 | 不把历史 UUID 当当前操作身份，不把读提示当持久执行票据 |
| 历史审计 | 原 principal/visit/event/来源关系可回溯，按原可见性规则返回 | 不为了“整洁”覆写旧记录，不要求旧登录能力永远 active |
| Agent / Broker | 获取当前状态，准备业务数据，以自己的原认证通道提交 | 不猜 UUID 等价、不维护授权缓存、不自动重放 UNKNOWN 写入 |

### 4.2 新写入政策（需要有限 Spec amendment）

选择明确的迁移终点：**新责任记录只保存已验证 canonical principal**。不能只把展示换名，而让后端继续制造 P→Q 兼容需求。

1. 新 definition/普通显式 assignee 输入按 canonical 合同验证；legacy 输入给有限、可操作的 typed 拒绝，不静默用显示名或 alias 改人。现有 definition 的旧常量通过原发布/修订流程更新，历史版本保留。
2. RETURN、既有任务恢复等内部来自历史的目标，由受支持的原服务端映射明确解析成 Q，再验证 active/role/admission，并在**新的**责任事实中持久化 Q；历史目标 P 保留为 provenance。不会改写旧 visit，也不会让调用方任意选择映射。
3. admission 内部接口应返回可消费的 validated target（至少 canonical principal、原输入身份与证据引用）；写端只能消费该结果，不能验证 Q 后又写 P。现有 idempotency payload/hash 仍绑定原请求，规范化不得篡改已签/已接收请求或改变重放语义。
4. 迁移期普通新请求不保留无限期双模式。旧模板/调用方的处理清单必须先收敛；需要临时兼容的只能是明确原迁移入口、封闭成员与退出条件，不建立全局 fallback 开关。
5. 已登记/已开始任务的身份变化按原事务/CAS/repair 生命周期办理；不能把后台重写 assignee 列当迁移。若原合同不能表达，提交那一处 amendment，而不是重批整个系统。

### 4.3 当前责任投影与角色矩阵

优先复用现有字段和共享函数；对当前可空 enrichment 的含义修订需要 DTO/consumer 同步，不静默改 API 语义。服务端对 canonical-native、合法 legacy successor、未解析三类给确定且一致的投影；未解析保留 UNKNOWN/typed reason，不能回退名称匹配。历史原字段保留在审计语义中，不冒充当前责任。

| 路径 | 共享的内容 | 必须保留的独立限制 |
| --- | --- | --- |
| detail/history/assigned list | current effective-assignee 的同源解释 | 原可见性、auditor/Domain 边界 |
| transition | effective current assignee | 当前 actor grant、payload、stateVersion、assistance、业务 guards |
| creator-draft / combined | assignee 子谓词 | exact creator、DRAFT、edit/revise 权限；继任 assignee ≠ creator |
| assistance write | 原 Spec 认可的当前责任部分 | open/closed、发起/接受角色及状态限制；未核原语义不盲替换 |
| admin/Domain Owner/auditor | 可以复用权威身份解析 | 各自独立 grant；auditor readonly 不转成业务写权 |

`resolve_current_principal` 的历史一边解析与 CTR-CIR 实例 repair lineage 不是任意可互换的数据源。保留既有 P9 合同的可审边界，不新增私有 mapping 表；不因一个 helper 不检查 active 就推论所有旧认证可直接关闭。

## 5. 实施顺序、交付与验收

### T0 — 接续已有修复和当前作者（先做）

- [ ] 在本 issue 登记当前作者、隔离 worktree、selected base/head、涉及文件、与正在做 creator-draft 的作者关系。已有同项工作直接消费，不重做。
- [ ] 对 10310a4 与 main 的差量做有限集成清单，选择保持四处修复的基线；不盲 cherry-pick 整条 auditor 分支，不覆盖当前生产修复。
- [ ] 原 creator-draft 在途改动先核有无扩大 `created_by` 语义；若有，保留差量待角色 Spec 明确，不当作已通过的普通 equality 修复。保留失败测试回执。
- [ ] 按各仓 `.agents/README.md` 输出 DEVELOPMENT_PREFLIGHT，列已接受覆盖和真实需 amendment 的 T1/T3 内容。不要创建多份重复审批/新 reviewer。

**交付：** 一份 source/base/owner/复用表与准确 PR 路由。**通过：** 原四处修复与现有测试没有丢失、没有第二作者覆盖同文件、没有生产变化。

### T1 — 停止新 legacy 责任产生

**Files：** 上述 admission_gate、publish、create/revise/combined/transition/admin/repair 与其现有测试；首先仅修改 governing Spec 的有限条款（单独 docs PR），其 accepted/main 后再进入实现 PR。

- [ ] 用第4.2节形成 amendment：显式输入、新内部责任、历史保留、admission返回与幂等语义。指出 T62 要被有意替换的旧要求；禁止实现 PR 顺手扩大自身 Spec。
- [ ] 在原 owned test DB 中先补/改失败测试：验证对象 Q 必须也是新 visit/receipt 的 responsibility；原 payload/provenance P 不被伪改；未绑定/disabled target 拒绝且无新增 visit。
- [ ] 复用权威 admission 和原事务写路径做最小实现，不创建第二身份目录。publish/defaults/revise/RETURN/admin/repair 都不能绕过新写入规范。
- [ ] 跑对应 `cargo test --test 31_admission_wiring`、`--test 32_definition_publish_admission` 及 affected runtime cases；使用该任务独立 schema/测试库，不连接共享/生产 DB。命令与 rc/时长落证，不声称旧测试自动通过。

**通过：** 普通新任务与所有合法后继路径产生 Q；旧不可变记录仍 P；canonicalization 不改变无关 role/grant；admission不可用/拒绝不得靠 legacy fallback 成功。

### T2 — 收口责任判定，保留角色边界

**Files：** `query_worklists.rs`、`assistance_transaction/write.rs`、现有 shared predicate、对应现有 query/combined/assistance tests。

- [ ] 先对已有 #82 与他线在途修复做差量接入。保留 shared helper 作为唯一同角色 assignee 判定源。
- [ ] 补 creator canonical + stored legacy assignee 的 advisory/combined 一致测试；非 creator successor 仍拒 revise。修的是 assignee 子谓词，不是扩大 creator 本身。
- [ ] 给 assigned-list OR 分支与 assistance 建角色对照：canonical successor、旧仍 active actor、outsider、revoked、assistance-open/closed。只改已证明与对应 Spec 冲突的路径。
- [ ] 运行受影响 query/transition/combined/assistance 以及原 domain-owner deny/auditor readonly 回归。不要以共享 DB 并行污染或另一路 auth 故障掩盖实际回归。

**通过：** 同一 actor/task/state 下读提示与写端共同资格相符，但写端独有条件仍可拒绝；旧 actor 不因 stored OR 分支获得未被角色合同允许的权力。

### T3 — 当前表面收敛与“旧拒绝经历”回归

**Files：** Workflow `query_visibility.rs`、`query_types.rs` 及其 DTO/serialization tests；DSH `packages/broker/src/capabilities/workflow.js` 与原工具描述/dispatcher 消费实现和测试。具体 dispatcher 文件由原作者沿现有入口定位后一次写入 preflight，不能新建旁路 dispatcher。

- [ ] Spec 定义 existing canonical enrichment 在 native canonical/继任/未解析三类的完整含义，current 与 historical 明确区分；精确列 consumer 兼容窗口，不能靠新增布尔补丁遮住原歧义。
- [ ] API/工具输出保持 current责任来自 Workflow；Broker 仍透传，不新增权限缓存/名字推断/预授权。历史视图仍可查原 UUID 和来源。
- [ ] 工具说明统一“恢复工作消费当前事实；读时可执行提示不是最终承诺；UNKNOWN 写入先查原结果”。删除有证据的历史 UUID 自行否决规则，不写 CTO 特例。
- [ ] 使用 synthetic 会话和 mock transport 做暖上下文回归：先给旧 principal 拒绝记录，再给新的真实同源责任结果，agent 应准备合法业务输入并通过原工具提交；不因旧经历永远只报状态。验证相反情况：现已撤权/outsider 仍停；旧写 UNKNOWN 不产生第二 mutation；业务材料缺失准确报告缺项而非假称身份门。
- [ ] 不用一次模型输出证明稳健性：固定 fixture/版本/工具 transcript 做可重复用例，并对实际工具调用断言；需要模型回归时记录样本与失败，不宣称概率为零。普通代码测试与模型行为证据分开。

**通过：** agent 不用认识两套 UUID；canonical-native 的 null enrichment 不再被误作他人；不新增认证能力；读时状态变化和 CAS 竞争由服务端正确拒绝/重新读取，不自动重发写入。

### T4 — 迁移与退役准备（本阶段只离线准备）

**Files：** 原 CTR-CIR identity repair/operator 与 `tests/34_identity_repair_operator.rs`；原 Auth 生命周期/目录的既有接口，不新增万能迁移脚本。

- [ ] 形成可复用 inventory schema：对象类别、原/新 principal、权威精确映射引用、当前 role/状态、引用该身份的 definition/client/grant/work item、拟处理动作、原 operator、前后条件、回滚边界、证据。未知不填“无依赖”。本轮不现场扫描敏感数据；先用已有合法材料和 owned fixture。
- [ ] 区分三类：仅历史无需迁移；当前责任可由已有投影合法处理且可自然结算；确需原 repair/migration。不要为得到“全 canonical”重建所有实例或重写历史。
- [ ] 用 owned DB 演练分批清单、version/CAS、幂等重复输入、失败中止/恢复、dry-run 不写和历史 hash 不变。旧 repair 的既定封闭集合不自动覆盖今天的新实例；真实新作用域只补那一项。
- [ ] 输出后续生产实施申请的精确变更集合/原责任方/前后像/回退条件；此任务交付不自动 APPLY、不 disable legacy principal、不撤 grant、不清会话。

**通过：** 每种活跃旧依赖都有来源与合法处理入口；无“先删再看谁坏”的迁移；无法解析的项有可归属隔离/处理状态，不算完成、不当永久全系统阻塞。

### T5 — 兼容执行路径退役与交付审查

- [ ] 在 isolated fixtures 证明第6节所有条件；代码可删除的旧分支与仍需保留的审计解析分列，不把残留审计读判作退役失败。
- [ ] 源码 ready 后对选定最终 HEAD 做一次受影响的独立审查，包含角色边界、migration、无绕权和 rollback；复用 unchanged evidence，不按每个字段开新审批轮。
- [ ] 正常合入流程与 release manifest 明确 Spec/source/test/review HEAD。身份源交付状态最多到 SOURCE_READY/MERGED，安装/enable/business 必须由原部署线另记。
- [ ] 在本 issue 给待部署清单与真实阻塞；无变更时不重复调查/刷回执。未部署的 retirement 条件保持 pending，不提前删生产兼容或关闭守卫。

## 6. 退役条件（逐类，而非一刀切）

| 要退役的东西 | 必须满足的退出条件 | 保留/回退边界 |
| --- | --- | --- |
| definition/template/创建接口里的 legacy 默认值与生成逻辑 | 已枚举受支持生产源，publish/create/revise/RETURN/admin/repair 测试全覆盖；新责任不再产生 legacy；所有被支持客户端使用新合同 | 历史 definition 版本保留；不能回滚到继续产生 P 的生成器 |
| 当前业务 API 的 legacy-as-current 展示 | detail/list/dispatcher 同一 current 投影；native canonical、继任、未解析都覆盖；消费者迁移完成 | 历史/audit 字段保留；必要双读窗口有明确版本终点，不无限兼容 |
| 重复裸 UUID/名称/本地 alias 授权分支 | 同角色判定只有一个服务端来源；所有允许/拒绝/CAS/assistance 对照通过 | 不删除与 assignee 不同的 creator/Domain/admin 权限检查 |
| legacy Auth 登录/机器客户端/grant 能力 | 原 Auth 负责人确认每项依赖已替换/结束，真实退役清单和原合法窗口明确；canonical 能力最小化且有独立 grant 依据；禁用旧认证的 owned 测试不破坏历史查询 | 可以保留历史 principal/tombstone/lineage，不能因密钥“失联”就推断可安全停用，更不能复制全部旧 grants |
| 当前执行对 legacy successor bridge 的依赖 | 活跃旧任务结算或通过合法原机制接续；RETURN/recovery 不复活旧执行；新写入全 canonical；当前操作可不走 bridge | 只把桥缩到历史读取/明确迁移边界。不能在仍有活跃旧引用时先删解析；也不能为留审计而永久保留旧登录 |
| 会话修补/全局提示词补丁 | 正常新会话、带旧拒绝的暖上下文都能恢复；原具体事件注册/loader修复已交付验证 | 不批量覆写记忆。确有局部会话损坏按原有备份/恢复流程另处理；不作为身份验收捷径 |
| websearch/artifact watchdog 等临时守卫 | 对应 #550/#554/#1276 上游修复已在实际消费世代验证，移除演练不再复现；由原部署线记录 retirement | 身份项目不擅自停止它们。离线 source PASS 不能当生产退役依据 |

退役不是只看连续若干小时“没有报错”。需同时有静态调用/配置清单、受支持路径测试、真实交付世代和依赖结束证据。若还需生产观测，提前说明观测覆盖的事件/窗口与原收集方式，不临时加全天候新守卫。

## 7. 验收矩阵与回滚

最低验收矩阵：

| 用例 | 预期 |
| --- | --- |
| canonical actor + canonical 当前责任 | 正常读、合法写；不依赖 lineage enrichment 非 null |
| canonical successor + 历史 P 责任 | 通过原合法映射取得当前责任；new visit 用 Q，history仍 P |
| outsider / revoked / 缺权威映射 / 名称相似 | 不得通过；不进入名称/前缀 fallback |
| 非 creator 的 successor 请求 combined/revise | creator 权限仍拒绝，即便其为当前 assignee |
| 旧 actor 仍 enabled | 不因“stored OR resolved”意外保留/扩大不属于它的当前权力；由角色合同明确结果 |
| assistance open、Domain Owner、auditor readonly | 各自独立权限与业务限制保持 |
| RETURN/admin/repair/旧模板 | 新责任不重生 legacy；未经授权不修旧历史或复制 grant |
| read true → 写前撤权/状态变化 | 写端拒绝/CAS冲突；无自动重复 mutation |
| 旧403会话 → 当前资格改变 | 合法恢复当前业务；缺业务数据准确报告，不把历史拒绝固化为永久身份规则 |
| 旧写 UNKNOWN → 当前资格通过 | 只恢复原 request，不能提交第二写入 |
| migration失败/重入/回滚 | 有界、幂等、前后条件可核；原历史hash/事件/审计关系不变 |
| disable legacy auth 的 owned演练 | 旧认证不可用但合法历史审计仍可读，canonical不获得额外权力 |

回滚分层：

1. 源码阶段使用隔离分支回退，保留全部已有修复；不能用回到旧 main 的方式撤掉 10310a4。
2. 后续发布需选择能读取 canonical 新数据的兼容版本；如果新写已生效，不能回退到只认识 legacy 的 reader。先做 schema/consumer兼容演练，再写切换/回退顺序。
3. 历史与迁移来源只追加，生产数据回滚由原 operator 的合法逆向/补偿合同承担；不能 DELETE lineage、UPDATE immutable visits 或恢复旧凭据来“回滚”。
4. 未被证实成功的写入保持原请求状态，不能因 rollback 重新发业务动作。

## 8. 监管、记录与加速

交给现有 agent 接续，首项是 T0（核在途作者和主线集成），然后 T1/T2/T3，T4/T5 在其依赖齐备后收口。已有部署在途不能被本 source 任务强行中断；没有冲突的 docs/owned tests 可以推进，但同文件只一个作者。既有 Sol 6.1 ultra 继续实施，监管负责任务归属和交接，不变成第二源码/生产 writer。

本 issue 使用单表更新 `task / owner / base+head / reused evidence / new delta / test+review / source state / deployment state / next`。状态：READY → CLAIMED → SPEC_DELTA（仅必要时）→ IMPLEMENTING → SOURCE_VERIFIED → REVIEWED → MERGED；生产的 INSTALLED/ENABLED/BUSINESS_VERIFIED 分列，本任务不填成功。每个完成项引用 commit/PR、针对性测试命令与 rc、独审结果，不只发“正在推进”。

复用 [#1276 耗时记录方案](https://github.com/mayf3/agent-control/issues/1276#issuecomment-6376830620)：记录排队、开发、命令、审查、交接等待、重做和真正 effect 的起止/因果/主体。单时钟域用 monotonic；累计工时与墙钟区间并集分开。无动作/无变化不要刷相同状态；需要人处理时给一个精确问题与已有材料。

减少治理开销的规则：一次冻结必要语义、一次 same-chain affected review；已通过证据按 exact HEAD/范围复用；Spec 与实现分开但不为每个 DTO 字段另开审批；没有真实权限/角色变化不去找新的 Owner。反过来，creator/admin/Auth grant 的真实权限差量不能被“统一身份”掩盖。

**本方案完成的定义：** 计划与证据已发布并交原监管，后续原 agent 能逐项实施；不是当前部署成功。**实现完成的定义：** 上述 source/test/review 与退役演练通过；不是自动批准生产 disable/migration。

## 9. 立即交接指令

请既有监管记录接收本 issue，先与正在改 creator-draft 的作者对齐并保留其已有成果/失败证据；避免扩大 `created_by` 权限与重复开发。将 10310a4 主线分叉集成、admission 验Q写P、nullable canonical投影和三处候选判定差量纳入现有 Sol 的隔离分支任务。先出必要有限 Spec amendment，再按 T0–T5 推进，进度与证据回本 issue。只完成源/测试/独审，不安装、不改生产数据/身份/凭据/会话，也不以这份计划替代原部署生命周期。

本轮自产只有计划与小证据/交接回执；无产品源码、测试执行、生产访问或新的实现 writer。原 evidence、在途 worktree、会话、DB 与失败回执均保留。

