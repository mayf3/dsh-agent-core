CREATE TABLE users (id uuid PRIMARY KEY);
-- CreateEnum
CREATE TYPE "PrincipalType" AS ENUM ('agent');

-- CreateEnum
CREATE TYPE "PrincipalStatus" AS ENUM ('active', 'disabled');

-- CreateEnum 
CREATE TYPE "ClientStatus" AS ENUM ('active', 'revoked');

-- CreateTable
CREATE TABLE "machine_principals" (
    "id" UUID NOT NULL,
    "principal_type" "PrincipalType" NOT NULL DEFAULT 'agent',
    "agent_id" TEXT NOT NULL,
    "owner_user_id" UUID NOT NULL,
    "display_name" TEXT,
    "status" "PrincipalStatus" NOT NULL DEFAULT 'active',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "disabled_at" TIMESTAMP(3),

    CONSTRAINT "machine_principals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "machine_clients" (
    "id" UUID NOT NULL,
    "client_id" TEXT NOT NULL,
    "machine_principal_id" UUID NOT NULL,
    "secret_hash" TEXT NOT NULL,
    "status" "ClientStatus" NOT NULL DEFAULT 'active',
    "allowed_resources" TEXT[],
    "allowed_scopes" TEXT[],
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "rotated_at" TIMESTAMP(3),
    "revoked_at" TIMESTAMP(3),

    CONSTRAINT "machine_clients_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "machine_principals_agent_id_key" ON "machine_principals"("agent_id");

-- CreateIndex
CREATE UNIQUE INDEX "machine_clients_client_id_key" ON "machine_clients"("client_id");

-- AddForeignKey
ALTER TABLE "machine_principals" ADD CONSTRAINT "machine_principals_owner_user_id_fkey" FOREIGN KEY ("owner_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "machine_clients" ADD CONSTRAINT "machine_clients_machine_principal_id_fkey" FOREIGN KEY ("machine_principal_id") REFERENCES "machine_principals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE machine_principals ALTER COLUMN owner_user_id DROP NOT NULL;
-- Add external_ref to machine_principals and machine_clients for generic
-- idempotent creation (AUTH_V1_GENERIC_IDEMPOTENT_PRINCIPAL_AND_CLIENT_CREATION).
--
-- external_ref is an opaque caller-provided unique key. Auth never parses it.
-- NULL allowed for existing legacy records; PostgreSQL unique constraints treat
-- multiple NULLs as distinct, so existing data is untouched.

ALTER TABLE "machine_principals"
  ADD COLUMN "external_ref" TEXT;

CREATE UNIQUE INDEX "machine_principals_external_ref_key"
  ON "machine_principals"("external_ref");

ALTER TABLE "machine_clients"
  ADD COLUMN "external_ref" TEXT;

CREATE UNIQUE INDEX "machine_clients_external_ref_key"
  ON "machine_clients"("external_ref");

-- MACHINE_CLIENT_CREDENTIALS_V0 Amendment A — Secret-Mutation Enforcement Seam
-- (external prerequisite (e) SECRET_MUTATION_ENFORCEMENT_SEAM)
--
-- Governing authority: auth-service docs/contracts/MACHINE_CLIENT_CREDENTIALS_V0.md §11.
-- Governing external spec: dsh-agent-core docs/specs/AGENT_CORE_AGENT_CREDENTIAL_PROVISIONING_V1.md
--   Amendment 7 Part I.2 (DIRECT_APP_ROLE_SECRET_UPDATE = IMPOSSIBLE;
--   SECRET_HASH_CHANGE_WITHOUT_ROTATION_AUDIT = IMPOSSIBLE).
--
-- Frozen properties (scope = ordinary supported production application/operator
-- DB identities; PostgreSQL superuser / host root is out of scope by definition):
--   1. The application/operator role can no longer UPDATE machine_clients'
--      secret_hash / rotated_at columns (real privilege boundary via ownership
--      separation + column-level grants).
--   2. Secret material changes ONLY via rotate_machine_client_secret() — a
--      SECURITY DEFINER function owned by the boundary role which atomically:
--      verifies the frozen preimage fingerprint, advances rotated_at/updated_at,
--      and appends an immutable receipt row (operation_id UNIQUE ⇒ replay of a
--      known operation id never mutates again).
--   3. Defense-in-depth trigger: even the owning role cannot change secret
--      material through ordinary row DML — only the SECURITY DEFINER context
--      (current_user = owner AND session_user <> current_user) passes.
--
-- OPERATIONAL CONSTRAINT (documented in contract §11): future DDL on
-- machine_clients must be applied as machine_credential_owner. This migration
-- must be applied by the table owner (the role that runs migrations).
--
-- ADMIN HANDSHAKE (three steps; the final REVOKE is required by PostgreSQL
-- grantor law — only the grantor (or a role with privileges of the grantor)
-- can revoke a membership grant, so the seal CANNOT be executed by the
-- migration role itself and MUST NOT be skipped):
--   1. AS ADMIN:  CREATE ROLE machine_credential_owner NOLOGIN;
--                 GRANT CREATE ON SCHEMA public TO machine_credential_owner;
--                   (the NEW owning role must hold CREATE on the schema —
--                    PostgreSQL requirement for ALTER ... OWNER TO)
--                 GRANT machine_credential_owner TO <migration_role>;
--   2. run THIS migration as <migration_role> (the current table owner);
--   3. AS ADMIN:  REVOKE machine_credential_owner FROM <migration_role>;
--      (seals the boundary). VERIFICATION DUTY (§11.4, mechanically checked
--      by the shipped enforcement suite): after step 3,
--      pg_has_role(<migration_role>,'machine_credential_owner','member') MUST
--      be false and SET ROLE MUST fail. While membership lingers, a member
--      could SET ROLE to the boundary role and the frozen properties are NOT
--      claimable — the suite turns that state into a loud RED.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'machine_credential_owner') THEN
    CREATE ROLE machine_credential_owner NOLOGIN;
  END IF;
  IF NOT pg_has_role(current_user, 'machine_credential_owner', 'MEMBER') THEN
    RAISE EXCEPTION 'OWNERSHIP_TRANSFER_PREREQUISITE: % must be a member of machine_credential_owner for this migration (admin handshake step 1: GRANT machine_credential_owner TO %; step 3 after migration: REVOKE). See contract §11.3', current_user, current_user;
  END IF;
END
$$;

ALTER TABLE machine_clients OWNER TO machine_credential_owner;

-- Application DML surface: everything EXCEPT the secret-material columns.
GRANT SELECT ON machine_clients TO current_user;
GRANT INSERT ON machine_clients TO current_user;
GRANT UPDATE (client_id, machine_principal_id, external_ref, status,
              allowed_resources, allowed_scopes, updated_at, revoked_at)
  ON machine_clients TO current_user;
-- Row deletion is NOT a secret mutation (no secret material is changed) and is
-- required by existing lifecycle/cleanup paths; audit receipts persist because
-- the ledger carries no FK (see below).
GRANT DELETE ON machine_clients TO current_user;

-- Rotation receipt ledger (PLAN→APPLY→VERIFY→RECEIPT). Append-only audit:
-- intentionally NO FK to machine_clients so receipts survive client deletion;
-- no DELETE/UPDATE grant is issued to the application role.
CREATE TABLE IF NOT EXISTS machine_client_rotations (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  operation_id          text NOT NULL UNIQUE,
  machine_client_id     uuid NOT NULL,
  client_id             text NOT NULL,
  preimage_fingerprint  text NOT NULL,
  postimage_fingerprint text NOT NULL,
  rotated_by            text NOT NULL,
  rotated_at            timestamp(3) NOT NULL,
  created_at            timestamp(3) NOT NULL DEFAULT now()
);
ALTER TABLE machine_client_rotations OWNER TO machine_credential_owner;
GRANT SELECT ON machine_client_rotations TO current_user;

-- The ONLY supported secret-mutation path (canonical explicit ROTATE seam).
CREATE OR REPLACE FUNCTION rotate_machine_client_secret(
  p_client_uuid          uuid,
  p_new_secret_hash      text,
  p_preimage_fingerprint text,
  p_operation_id         text,
  p_rotated_by           text
)
RETURNS TABLE (client_id text, rotated_at timestamp(3), receipt_id uuid, replayed boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_row         machine_clients;
  v_existing    machine_client_rotations;
  v_preimage_fp text;
  v_post_fp     text;
  v_rotated_at  timestamp(3);
  v_receipt_id  uuid;
BEGIN
  -- Deterministic replay: a known operation id never mutates again.
  SELECT * INTO v_existing FROM machine_client_rotations
   WHERE operation_id = p_operation_id;
  IF FOUND THEN
    client_id := v_existing.client_id;
    rotated_at := v_existing.rotated_at;
    receipt_id := v_existing.id;
    replayed := true;
    RETURN NEXT;
    RETURN;
  END IF;

  -- Exact target + preimage generation check (fail closed, zero mutation).
  SELECT * INTO v_row FROM machine_clients WHERE id = p_client_uuid FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'ROTATION_TARGET_NOT_FOUND';
  END IF;
  IF v_row.status <> 'active' THEN
    RAISE EXCEPTION 'ROTATION_TARGET_NOT_ACTIVE';
  END IF;
  v_preimage_fp := encode(sha256(convert_to(v_row.secret_hash, 'utf8')), 'hex');
  IF v_preimage_fp <> lower(p_preimage_fingerprint) THEN
    RAISE EXCEPTION 'ROTATION_PREIMAGE_MISMATCH: live secret generation does not match frozen preimage (live=%, expected=%)', left(v_preimage_fp, 12), left(lower(p_preimage_fingerprint), 12);
  END IF;

  v_post_fp := encode(sha256(convert_to(p_new_secret_hash, 'utf8')), 'hex');
  v_rotated_at := now();

  UPDATE machine_clients
     SET secret_hash = p_new_secret_hash,
         rotated_at  = v_rotated_at,
         updated_at  = v_rotated_at
   WHERE id = p_client_uuid;

  INSERT INTO machine_client_rotations
    (operation_id, machine_client_id, client_id, preimage_fingerprint,
     postimage_fingerprint, rotated_by, rotated_at)
  VALUES
    (p_operation_id, p_client_uuid, v_row.client_id, v_preimage_fp,
     v_post_fp, p_rotated_by, v_rotated_at)
  RETURNING id INTO v_receipt_id;

  client_id := v_row.client_id;
  rotated_at := v_rotated_at;
  receipt_id := v_receipt_id;
  replayed := false;
  RETURN NEXT;
END;
$$;
ALTER FUNCTION rotate_machine_client_secret(uuid, text, text, text, text)
  OWNER TO machine_credential_owner;
REVOKE ALL ON FUNCTION rotate_machine_client_secret(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION rotate_machine_client_secret(uuid, text, text, text, text)
  TO current_user;

-- Defense-in-depth: block secret-material changes through ordinary row DML for
-- EVERY role except the SECURITY DEFINER context of the rotation function.
CREATE OR REPLACE FUNCTION machine_clients_secret_guard()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $$
BEGIN
  IF NEW.secret_hash IS DISTINCT FROM OLD.secret_hash
     OR NEW.rotated_at IS DISTINCT FROM OLD.rotated_at THEN
    -- Allow ONLY a genuine SECURITY DEFINER switch (current_user flipped by
    -- the definer mechanism, which does NOT touch the session `role` GUC).
    -- A role member reproducing the pair via `SET ROLE` sets the `role` GUC
    -- to the boundary role and is rejected here — SET ROLE is NOT a seam.
    IF current_user = 'machine_credential_owner'
       AND session_user <> current_user
       AND coalesce(current_setting('role'), 'none') IN ('none', 'unset') THEN
      RETURN NEW;
    END IF;
    RAISE EXCEPTION 'MACHINE_CLIENT_SECRET_MUTATION_OUTSIDE_ROTATION_SEAM';
  END IF;
  RETURN NEW;
END;
$$;
ALTER FUNCTION machine_clients_secret_guard() OWNER TO machine_credential_owner;

DROP TRIGGER IF EXISTS machine_clients_secret_guard ON machine_clients;
CREATE TRIGGER machine_clients_secret_guard
BEFORE UPDATE ON machine_clients
FOR EACH ROW EXECUTE FUNCTION machine_clients_secret_guard();

-- ── SEAL STATUS (contract §11.3 / §11.4) ─────────────────────────────────
-- PostgreSQL grantor law: the migration role cannot revoke a membership
-- granted by the admin (empirically verified on PG16 — ADMIN OPTION does not
-- confer grantor-revocation). The seal is therefore handshake step 3, an
-- ADMIN action, and it is DETECTABLE: the shipped enforcement suite fails
-- loudly while membership lingers, so a skipped step 3 cannot pass silently.
DO $$
BEGIN
  IF pg_has_role(current_user, 'machine_credential_owner', 'member') THEN
    RAISE WARNING 'BOUNDARY_SEAL_PENDING: membership of % in machine_credential_owner is still present — execute admin handshake step 3 (REVOKE machine_credential_owner FROM %) BEFORE claiming DIRECT_APP_ROLE_SECRET_UPDATE = IMPOSSIBLE. The shipped enforcement suite will fail until the seal is applied.', current_user, current_user;
  END IF;
END $$;

-- ROTATION_NULL_PREIMAGE_GUARD (T87 / AUTH-SCOUT-20260914-C05):
-- The canonical ROTATE seam must reject a NULL preimage fingerprint.
--
-- OWNER SECURITY DECISION (OWNER_GATE_MATERIALIZATION_AND_NIGHTLY_RELEASE_20260916_V1,
-- recorded verbatim in the queue ticket OWNER_DECISION_COMMIT block):
--   NULL preimage → reject; wrong preimage → reject; correct preimage →
--   rotate. The first two perform ZERO credential mutation.
--
-- DEFECT: the 20260913 function compared the live fingerprint with
--   v_preimage_fp <> lower(p_preimage_fingerprint)
-- Under SQL three-valued logic a NULL p_preimage_fingerprint makes that
-- predicate NULL, the IF treats it as false, the mismatch branch never
-- fires, and the secret rotated with NO preimage proof. The replay-branch
-- live-state invariant already uses IS DISTINCT FROM for exactly this
-- reason; the preimage guard now does the same.
--
-- ADMIN HANDSHAKE (same three steps as 20260909010000/20260913; the CREATE
-- OR REPLACE below must run as/with the function owner machine_credential_owner):
--   1. AS ADMIN: GRANT machine_credential_owner TO <migration_role>;
--   2. run THIS migration as <migration_role>;
--   3. AS ADMIN: REVOKE machine_credential_owner FROM <migration_role>;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'machine_credential_owner') THEN
    RAISE EXCEPTION 'OWNERSHIP_TRANSFER_PREREQUISITE: role machine_credential_owner missing (see 20260909010000 handshake)';
  END IF;
  IF NOT pg_has_role(current_user, 'machine_credential_owner', 'MEMBER') THEN
    RAISE EXCEPTION 'OWNERSHIP_TRANSFER_PREREQUISITE: % must be a member of machine_credential_owner for this migration (handshake step 1)', current_user;
  END IF;
END
$$;

CREATE OR REPLACE FUNCTION rotate_machine_client_secret(
  p_client_uuid          uuid,
  p_new_secret_hash      text,
  p_preimage_fingerprint text,
  p_operation_id         text,
  p_rotated_by           text
)
RETURNS TABLE (client_id text, rotated_at timestamp(3), receipt_id uuid, replayed boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_row         machine_clients;
  v_existing    machine_client_rotations;
  v_preimage_fp text;
  v_post_fp     text;
  v_rotated_at  timestamp(3);
  v_receipt_id  uuid;
  v_live_fp     text;
BEGIN
  -- Deterministic replay: a known operation id never mutates again — and it
  -- is bound to exactly the target it originally rotated.
  SELECT * INTO v_existing FROM machine_client_rotations
   WHERE operation_id = p_operation_id;
  IF FOUND THEN
    -- (1) Target binding: the operation is bound to the client it rotated.
    IF v_existing.machine_client_id <> p_client_uuid THEN
      RAISE EXCEPTION 'IDEMPOTENCY_CONFLICT: operation_id % is bound to a different rotation target (no mutation performed)', left(p_operation_id, 64);
    END IF;
    -- (3) Live-state invariant: the live secret generation must still equal
    -- the receipt postimage; otherwise this receipt describes a credential
    -- generation that no longer exists.
    SELECT encode(sha256(convert_to(secret_hash, 'utf8')), 'hex')
      INTO v_live_fp
      FROM machine_clients WHERE id = p_client_uuid;
    IF v_live_fp IS DISTINCT FROM lower(v_existing.postimage_fingerprint) THEN
      RAISE EXCEPTION 'STALE_IDEMPOTENCY_RECEIPT: live credential generation has advanced past receipt %', left(p_operation_id, 64);
    END IF;
    -- (2) Immutable receipt metadata replay (never re-emits secret material;
    --     the service layer strips credential material from this response).
    client_id := v_existing.client_id;
    rotated_at := v_existing.rotated_at;
    receipt_id := v_existing.id;
    replayed := true;
    RETURN NEXT;
    RETURN;
  END IF;

  -- Exact target + preimage generation check (fail closed, zero mutation).
  -- T87: IS DISTINCT FROM — a NULL preimage fingerprint is a MISMATCH, never
  -- a pass-through (three-valued <> evaluated to NULL and skipped the guard).
  SELECT * INTO v_row FROM machine_clients WHERE id = p_client_uuid FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'ROTATION_TARGET_NOT_FOUND';
  END IF;
  IF v_row.status <> 'active' THEN
    RAISE EXCEPTION 'ROTATION_TARGET_NOT_ACTIVE';
  END IF;
  v_preimage_fp := encode(sha256(convert_to(v_row.secret_hash, 'utf8')), 'hex');
  IF v_preimage_fp IS DISTINCT FROM lower(p_preimage_fingerprint) THEN
    RAISE EXCEPTION 'ROTATION_PREIMAGE_MISMATCH: live secret generation does not match frozen preimage (live=%, expected=%)', left(v_preimage_fp, 12), left(lower(p_preimage_fingerprint), 12);
  END IF;

  v_post_fp := encode(sha256(convert_to(p_new_secret_hash, 'utf8')), 'hex');
  v_rotated_at := now();

  UPDATE machine_clients
     SET secret_hash = p_new_secret_hash,
         rotated_at  = v_rotated_at,
         updated_at  = v_rotated_at
   WHERE id = p_client_uuid;

  INSERT INTO machine_client_rotations
    (operation_id, machine_client_id, client_id, preimage_fingerprint,
     postimage_fingerprint, rotated_by, rotated_at)
  VALUES
    (p_operation_id, p_client_uuid, v_row.client_id, v_preimage_fp,
     v_post_fp, p_rotated_by, v_rotated_at)
  RETURNING id INTO v_receipt_id;

  client_id := v_row.client_id;
  rotated_at := v_rotated_at;
  receipt_id := v_receipt_id;
  replayed := false;
  RETURN NEXT;
END;
$$;
ALTER FUNCTION rotate_machine_client_secret(uuid, text, text, text, text)
  OWNER TO machine_credential_owner;
REVOKE ALL ON FUNCTION rotate_machine_client_secret(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION rotate_machine_client_secret(uuid, text, text, text, text)
  TO current_user;
